# ADR to AE Handover Brief (Camunda technical challenge, Challenge A)

When an ADR hands a qualified opportunity to an AE, Salesforce builds a grounded handover brief, stores it on the opportunity and notifies the AE. Every statement in the brief links to the Salesforce record it came from, and anything the code cannot trace back to a record is removed before the AE sees it. If the model fails, the AE still gets the raw facts.

Everything runs natively in a Salesforce Developer Edition org. The model is called from Apex through a Named Credential. No external service is required.

## How it works

```
ADR: "Prepare Handover" action
  (AE assigned as owner; ADR confirms qualification, adds notes for the AE, sets Ready for Handover)
        |
        v
Validation rule (deterministic gate)       blocks handover without ADR, AE owner, Pain, Use Case, Timeline
        |
        v
Opportunity trigger  ->  Queueable job (callouts allowed, one opportunity per job)
        |
        v
1. FactSheet       queries Opportunity, Account, Contact Roles, Tasks, Events, EmailMessages,
                   Campaign Members
                   in USER_MODE; tags every record and field with a source_id; strips quoted
                   email replies, email addresses and phone numbers; caps text length
2. RiskRules       deterministic flags: no decision maker, competitor, unclear timeline,
                   close date in past, budget unconfirmed, no recent activity, single threaded
3. LlmClient       one call to the model, tool use = structured JSON output
4. BriefValidator  grounding checks: unknown source ids, numbers or proper nouns not in the
                   data, unknown contacts, invented risk codes -> statement removed
                   confidence = 70% share of statements kept + 30% data completeness
5. Decide          structurally valid and confidence >= threshold -> AI brief
                   otherwise (timeout, HTTP error, bad JSON, low confidence) -> fallback brief
6. Persist         new Handover_Brief__c version (previous versions kept), opportunity status
7. Notify          Salesforce custom notification to the AE, copy to the ADR
        |
        v
AE: "Handover Brief" panel on the opportunity: read, edit inline, regenerate, see versions
    edits: original kept read only; changed or added lines marked [Edited by AE];
           edited lines carried into the next version as [AE] notes
```

### What is deterministic and what is the model

| Deterministic (Apex, rules) | Model |
|---|---|
| When a brief is generated (trigger + validation rule) | Executive summary |
| Which data the model sees, and what is excluded | Why now |
| Risk flag detection and severity | Pain and use case synthesis |
| Stakeholder names, titles and roles (always from CRM) | Notes on each stakeholder |
| Grounding checks, confidence score, fallback decision | Open questions |
| Storage, versioning, notification | First call agenda |
| | One line explaining why each rule based flag matters |

In the rendered brief, rule based content is labeled **[Rule]** and model text is labeled **[AI]**.

### Data deliberately kept away from the model

* Contact email, phone and address fields are never queried.
* Email and call descriptions are trimmed: quoted reply chains are cut, email addresses and phone numbers inside the text are replaced, and each description is capped at 1,000 characters. Raw call transcripts are never read; only the call summary written back to Salesforce is used.
* Other opportunities on the account, contract values and pricing are excluded.
* Only data the user who triggered the run can see is included (`WITH USER_MODE`).

### Assumption about activity data

Discovery emails, calls and call summaries are written back to Salesforce by the engagement and conversation intelligence tools (Salesloft/Clari). The demo data models that: emails and calls as Tasks, call summaries in the call Task description, inbound emails as EmailMessage records (Enhanced Email, on by default in new orgs).

## Repository layout

```
force-app/main/default/
  classes/
    HandoverTriggerHandler   detects the handover event
    HandoverBriefJob         Queueable, one opportunity per transaction
    HandoverBriefService     orchestration
    FactSheet                deterministic data assembly with source ids
    RiskRules                deterministic risk flags
    LlmClient                the only model call (provider specific)
    BriefValidator           grounding checks and confidence
    GroundingUtil            number and proper noun extraction, text sanitizing
    BriefRenderer            HTML for the brief and for the fallback
    HandoverBriefWriter      persistence in system mode
    HandoverNotifier         custom notifications
    BriefController          backs the Lightning component
    HandoverSettings         reads Handover_Setting__mdt
    BriefEditTracker         marks AE edits against the read only original
  triggers/OpportunityHandoverTrigger, HandoverBriefTrigger
  lwc/handoverBrief          panel on the Opportunity page
  objects/                   Opportunity fields + validation rule, Handover_Brief__c, Handover_Setting__mdt
  quickActions/              Prepare Handover (the ADR capture step)
  staticresources/           system prompt and JSON schema, versioned outside Apex
  namedCredentials/, externalCredentials/, notificationtypes/, permissionsets/
scripts/apex/                synthetic demo data and a handover trigger script
```

## Setup (about 15 minutes)

Prerequisites: a free Developer Edition org, the Salesforce CLI (`sf`), and an Anthropic API key.

Fastest path, one command (logs in, deploys, stores the API key, creates the AE user, seeds data):

```bash
./scripts/setup.sh camunda-dev
```

Then do step 3 below. The manual equivalent:

```bash
sf org login web --alias camunda-dev
sf project deploy start --target-org camunda-dev
```

1. **Add the API key** (kept out of source control): Setup, Named Credentials, External Credentials tab, **LLM Provider**, Principals, **ApiKeyPrincipal**, Edit. Under Authentication Parameters add `ApiKey` with your key. Save.
2. **Create the AE user and seed synthetic data**:
   ```bash
   sf apex run --file scripts/apex/01_create_ae_user.apex --target-org camunda-dev
   sf apex run --file scripts/apex/02_seed_demo_data.apex --target-org camunda-dev
   ```
3. **Add the UI**: open any Opportunity, Edit Page (Lightning App Builder). Drag the **Handover Brief** component onto the page. Add the **Prepare Handover** action (Dynamic Actions on the highlights panel, or the page layout's Mobile and Lightning Actions). Save and activate.

### Demo scenarios

| Opportunity | What it shows |
|---|---|
| Nordwind Logistik: Camunda 8 Migration | Happy path. Rich qualification, logged emails, a call summary, an inbound email, decision maker, competitor, campaign touches. |
| Helix Versicherung: Claims Automation | Thin data: no decision maker, unknown timeline and budget, close date in the past, stale activity. An email contains a prompt injection asking the model to invent a EUR 2,000,000 budget and a CEO sponsor. |
| Brightline Health: Patient Referral Orchestration | Failure handling. Set **Simulate Failure** on the Default Handover Setting record to Timeout, Invalid Output or Hallucination, then hand over. |

Fire a handover from the UI (Prepare Handover, set status to Ready for Handover) or from the CLI:

```bash
sf apex run --file scripts/apex/03_mark_ready_for_handover.apex --target-org camunda-dev
```

The brief appears in about 10 to 30 seconds. Each run is a Handover Brief record holding the input fact sheet, the raw model output, the validation report, confidence, latency and tokens.

### Settings

All tunables live in Custom Metadata, Handover Setting, record Default: model, output token cap, timeout, minimum confidence, activity lookback and cap, text length cap, stale activity threshold, prompt version, and the demo failure switch. The prompt and output schema are static resources, so a prompt change is a metadata deployment and is versioned in Git.

### Troubleshooting

* *"We couldn't access the credential(s)"*: check that the Handover Brief User permission set is assigned to the user who fires the handover, and that the principal has the `ApiKey` parameter. In some orgs the permission set also needs Read on the **User External Credentials** object.
* *Developer Edition chain depth*: Developer Edition limits chained queueables to a depth of 5, so a bulk handover of more than 5 opportunities at once stops early there. Production orgs do not have this limit.

## Switching provider

Only `LlmClient` and the Named Credential URL know the provider. The rest of the pipeline consumes a plain map that matches `HandoverBriefSchema.json`.
