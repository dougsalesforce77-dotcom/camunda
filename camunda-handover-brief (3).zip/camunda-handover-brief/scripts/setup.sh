#!/usr/bin/env bash
# One command setup for a Developer Edition org:
#   ./scripts/setup.sh [org-alias]
# Logs in (browser) if needed, deploys, stores the LLM API key in the External Credential,
# creates the AE user, seeds the synthetic demo data, and opens the org.
set -euo pipefail
cd "$(dirname "$0")/.."
ALIAS="${1:-camunda-dev}"
API_VERSION="62.0"

step() { printf '\n==> %s\n' "$1"; }

step "Checking the Salesforce CLI"
command -v sf >/dev/null || { echo "Install the Salesforce CLI first: npm install -g @salesforce/cli"; exit 1; }

step "Connecting to org '$ALIAS'"
if ! sf org display --target-org "$ALIAS" >/dev/null 2>&1; then
    if [ ! -t 0 ]; then
        echo "Not logged in to '$ALIAS'. Run this in your own Terminal first: sf org login web --alias $ALIAS"
        exit 1
    fi
    echo "A browser window will open. Log in to your Developer Edition org."
    sf org login web --alias "$ALIAS" --set-default
fi

step "Deploying metadata"
sf project deploy start --target-org "$ALIAS" --wait 20

step "Storing the API key in the LLM Provider External Credential"
# Key comes from the LLM_API_KEY environment variable, or a hidden prompt when run by hand.
API_KEY="${LLM_API_KEY:-}"
if [ -z "$API_KEY" ] && [ -t 0 ]; then
    printf "Paste your Anthropic API key (input hidden, press Enter to skip and set it in Setup later): "
    read -rs API_KEY
    echo
fi
if [ -z "$API_KEY" ]; then
    echo "No API key provided. Add it in Setup (see the last step below)."
else
    BODY_FILE="$(mktemp)"
    chmod 600 "$BODY_FILE"
    trap 'rm -f "$BODY_FILE"' EXIT
    printf '{"externalCredential":"LLM_Provider","principalName":"ApiKeyPrincipal","principalType":"NamedPrincipal","credentials":{"ApiKey":{"value":"%s","encrypted":true}}}' "$API_KEY" > "$BODY_FILE"
    if sf api request rest "/services/data/v${API_VERSION}/named-credentials/credential" --method POST --body "@$BODY_FILE" --target-org "$ALIAS" >/dev/null 2>&1 \
        || sf api request rest "/services/data/v${API_VERSION}/named-credentials/credential" --method PUT --body "@$BODY_FILE" --target-org "$ALIAS" >/dev/null 2>&1; then
        echo "API key stored."
    else
        echo "Could not store the key through the API. Add it in Setup instead (see the last step below)."
    fi
    rm -f "$BODY_FILE"
    unset API_KEY
fi

step "Creating the AE user and assigning the permission set"
sf apex run --file scripts/apex/01_create_ae_user.apex --target-org "$ALIAS" | grep -E "USER_DEBUG|Error|error" || true

step "Seeding synthetic demo data"
sf apex run --file scripts/apex/02_seed_demo_data.apex --target-org "$ALIAS" | grep -E "USER_DEBUG|Error|error" || true

cat <<'EOF'

==> Two manual steps left (about 3 minutes):
 1. Open any Opportunity, click the gear icon, Edit Page. Drag "Handover Brief" (Custom
    components) onto the page. Add the "Prepare Handover" action (Dynamic Actions on the
    highlights panel, or the page layout's Mobile and Lightning Actions). Save and Activate.
 2. Only if the API key step was skipped or failed: Setup, Named Credentials, External
    Credentials, LLM Provider, Principals, ApiKeyPrincipal, Edit, add Authentication
    Parameter "ApiKey" with your key.

Then fire a handover:  sf apex run --file scripts/apex/03_mark_ready_for_handover.apex --target-org <alias>
EOF

[ -t 0 ] && sf org open --target-org "$ALIAS" --path "lightning/o/Opportunity/list" || true
