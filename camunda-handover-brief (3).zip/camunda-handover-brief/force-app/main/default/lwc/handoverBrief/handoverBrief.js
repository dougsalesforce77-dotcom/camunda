import { LightningElement, api, wire } from 'lwc';
import { refreshApex } from '@salesforce/apex';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getCurrentBrief from '@salesforce/apex/BriefController.getCurrentBrief';
import regenerate from '@salesforce/apex/BriefController.regenerate';
import saveBrief from '@salesforce/apex/BriefController.saveBrief';
import LightningConfirm from 'lightning/confirm';

const POLL_MS = 4000;
const MAX_POLLS = 30;

export default class HandoverBrief extends NavigationMixin(LightningElement) {
    @api recordId;
    brief;
    error;
    regenerating = false;
    wiredResult;
    previousId;
    polls = 0;
    refreshedOnLoad = false;
    editing = false;
    saving = false;
    draft;
    showOriginal = false;

    @wire(getCurrentBrief, { opportunityId: '$recordId' })
    wiredBrief(result) {
        this.wiredResult = result;
        // Cached data can survive a page reload; fetch fresh data from the server once on load.
        if (!this.refreshedOnLoad && (result.data !== undefined || result.error)) {
            this.refreshedOnLoad = true;
            refreshApex(this.wiredResult);
        }
        if (result.data !== undefined) {
            this.brief = result.data;
            this.error = undefined;
            if (this.regenerating && this.brief && this.brief.Id !== this.previousId) {
                this.regenerating = false;
                this.toast('New brief version ready', '', this.isFallback ? 'warning' : 'success');
            }
        } else if (result.error) {
            this.error = this.message(result.error);
        }
    }

    get hasBrief() {
        return !!this.brief;
    }

    get noBrief() {
        return !this.brief;
    }

    get isFallback() {
        return this.brief && this.brief.Status__c === 'Fallback';
    }

    get statusLabel() {
        return this.isFallback ? `Fallback: ${this.brief.Failure_Code__c}` : 'AI brief, grounded';
    }

    get badgeClass() {
        return this.isFallback ? 'slds-theme_warning' : 'slds-theme_success';
    }

    get isEdited() {
        return this.brief && this.brief.Edited_By_AE__c;
    }

    get editLine() {
        const b = this.brief;
        const who = b.Edited_By__r ? b.Edited_By__r.Name : 'a user';
        const when = b.Edited_At__c ? new Date(b.Edited_At__c).toLocaleString() : '';
        return `Edited by ${who} ${when}: ${b.AE_Edit_Summary__c || ''}.`;
    }

    get originalToggleLabel() {
        return this.showOriginal ? 'Show current version' : 'Show AI original';
    }

    toggleOriginal() {
        this.showOriginal = !this.showOriginal;
    }

    handleEdit() {
        this.draft = this.brief.Brief__c;
        this.showOriginal = false;
        this.editing = true;
    }

    handleDraftChange(event) {
        this.draft = event.target.value;
    }

    handleCancel() {
        this.editing = false;
        this.draft = undefined;
    }

    async handleSave() {
        this.saving = true;
        try {
            await saveBrief({ briefId: this.brief.Id, html: this.draft });
            this.editing = false;
            await refreshApex(this.wiredResult);
            this.toast('Brief saved', 'Your changes are marked as AE edits.', 'success');
        } catch (e) {
            this.toast('Could not save', this.message(e), 'error');
        } finally {
            this.saving = false;
        }
    }

    get metaLine() {
        const b = this.brief;
        const confidence = b.Confidence__c === null || b.Confidence__c === undefined ? 'n/a' : `${b.Confidence__c}/100`;
        const created = new Date(b.CreatedDate).toLocaleString();
        return `Version ${b.Version__c}  |  Confidence ${confidence}  |  ${b.Model__c || ''}  |  ${created}`;
    }

    async handleRegenerate() {
        if (this.isEdited) {
            const ok = await LightningConfirm.open({
                label: 'Regenerate brief',
                message: 'A new version will be generated from the latest Salesforce data. Your edited lines will be carried into it as AE notes, and this version stays in the history.',
                theme: 'default'
            });
            if (!ok) {
                return;
            }
        }
        this.previousId = this.brief ? this.brief.Id : null;
        try {
            await regenerate({ opportunityId: this.recordId });
            this.regenerating = true;
            this.polls = 0;
            this.poll();
        } catch (e) {
            this.toast('Could not regenerate', this.message(e), 'error');
        }
    }

    poll() {
        if (!this.regenerating) {
            return;
        }
        if (this.polls >= MAX_POLLS) {
            this.regenerating = false;
            this.toast('Still working', 'Refresh the page in a minute to see the new version.', 'info');
            return;
        }
        this.polls += 1;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        setTimeout(() => {
            refreshApex(this.wiredResult).then(() => this.poll());
        }, POLL_MS);
    }

    handleVersions() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Opportunity',
                relationshipApiName: 'Handover_Briefs__r',
                actionName: 'view'
            }
        });
    }

    toast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    message(e) {
        return (e && e.body && e.body.message) || (e && e.message) || 'Unknown error';
    }
}
