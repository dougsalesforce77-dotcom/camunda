trigger HandoverBriefTrigger on Handover_Brief__c(before insert, before update) {
    if (Trigger.isInsert) {
        BriefEditTracker.beforeInsert(Trigger.new);
    } else {
        BriefEditTracker.beforeUpdate(Trigger.new, Trigger.oldMap);
    }
}
