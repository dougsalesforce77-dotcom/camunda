trigger OpportunityHandoverTrigger on Opportunity(after insert, after update) {
    HandoverTriggerHandler.handle(Trigger.new, Trigger.isUpdate ? Trigger.oldMap : null);
}
