@@TASK1
### Which challenge I chose and why

**Challenge A.** A wrong sentence in a handover brief goes straight into a customer call, so grounding, fallback and human review are the product, not extras.

Today the handover is a mix of Slack, notes fields and memory. I moved the handover itself into Salesforce: the ADR uses a **Prepare Handover** action to confirm qualification and add notes for the AE, and a validation rule blocks the handover until the minimum is captured. Emails, calls and call summaries are written back to Salesforce by Salesloft/Clari (confirmed), and the synthetic data models exactly that.

### Assumptions

- The ADR creates the opportunity, and the AE is assigned as owner before the handover is marked ready.
- Each opportunity has one AE, who is the opportunity owner and the person notified.
- Qualification lives in Opportunity fields I modeled (Pain, Use Case, Timeline, Budget Status, Authority and Decision Process, Competitors, Current Solution, ADR notes), and decision makers are identified through standard Contact Roles.
- Activity from the last 120 days is the relevant context for a first call.
- An external LLM API is acceptable under a DPA with EU processing and zero retention.
- Briefs are written in English, even when notes are in German.
- The brief is advisory and never writes to Opportunity fields; a Salesforce notification is enough to alert the AE, with Slack as an easy addition.
- Volume is a few hundred handovers a month, which shapes the cost and limits estimates.

### Environment

**Salesforce Developer Edition, fully native.** Apex calls the Anthropic API through a Named Credential, so the key never appears in code. Setup: `./scripts/setup.sh <alias>` deploys, stores the key, creates the AE user and seeds three synthetic deals. Then add the Handover Brief component and the Prepare Handover action to the Opportunity page. The README has the details.

### Links

- Code: attached to my submission email as `camunda-handover-brief.zip` (a git repository; the README covers setup)
- Video walkthrough: https://www.loom.com/share/206b4250c9fd48df9bec10ebe88c2cc9

### Design summary

**Trigger.** The ADR sets Handover Status to Ready for Handover. I did not use "opportunity created by an ADR with a different owner": opportunities are often created before qualification is done, and owner changes also happen for territory moves. A status is deliberate, can be gated by a validation rule (ADR set, AE is owner, Pain, Use Case and Timeline filled) and can be repeated.

**Data flow.** The trigger queues an async job, one opportunity per job, because callouts cannot run in triggers and each transaction has a 120 second callout budget.

- **Fact sheet (deterministic):** Opportunity and qualification fields, Account firmographics, Contact Roles, Tasks, Events, EmailMessages and Campaign Members, queried in user mode. Every record and field gets a source id.
- **Risk flags (rules):** no decision maker, competitor present, unclear timeline, close date in the past, budget unconfirmed, no recent activity, single threaded. Thresholds live in Custom Metadata.
- **Model call:** one tool use call. The brief comes back as JSON matching a schema: summary, why now, stakeholders, pain and use case, open questions, first call agenda and risk explanations. Every item cites source ids. The prompt and schema are versioned static resources.
- **Grounding checks (code):** a statement is removed if it cites an unknown source, or contains a number or a capitalized name that is not in the data. Stakeholder names, titles and roles always come from CRM. Rule flags the model skips are added back.
- **Confidence (computed, not self reported):** 70% the share of statements kept, 30% data completeness.

**Output.** Each run creates a Handover Brief record on the Opportunity holding the brief, the exact model input and output, a validation report, confidence, latency and tokens. Every statement links to its source record. Rule content is labeled **[Rule]** and model text **[AI]**. The AE gets a Salesforce notification and the ADR a copy.

**Failure.** On a timeout, an HTTP error, invalid or truncated output, or confidence below 60, the AE still gets the raw facts and rule flags with a clear "not generated" banner and notification. The failure is stored on the run record, which is the log.

**Edit and regenerate.** The AE edits inline on the Opportunity. The generated original is kept read only and changed lines are marked **[Edited by AE]**. Regenerate creates a new version, keeps the history and carries the AE's lines over as labeled **[AE]** notes, which are never sent back to the model.

**Excluded from the prompt.** Contact emails, phones and addresses; quoted email threads; raw call transcripts (only the written back summary is used); other deals and pricing. Reasons: GDPR minimization, a smaller prompt injection surface, and cost.

### Testing and evaluation

**Tests I would write (Apex with HttpCalloutMock):** the trigger fires once and in bulk; the validation rule blocks each gap; every failure path produces a fallback, a notification and a failure code; validator cases for unknown sources, invented contacts, numbers, names and risk codes; user mode visibility; versioning and edit tracking.

**Output quality:** a golden set of about 30 synthetic deals (rich, thin, contradictory, German, adversarial) with facts each brief must contain and must not claim. Per run: removal rate, recall of must have facts, zero false claims. Citation precision judged by a second model with a 10% human spot check. In production: AE ratings, edit volume, regeneration and fallback rates.

@@TASK2
**1. Test in a sandbox.** Apex tests for every path above with 90% coverage on these classes, Code Analyzer in CI, and testing with real ADR and AE profiles in a private sharing model.

**2. Evaluation gate.** Run the golden set in a full copy sandbox. Every run stores its input and output, so scoring happens offline. Any prompt, schema or model change must pass before merge.

**3. Security.** DPA, EU processing and zero retention terms with the provider; the field allowlist reviewed with Security; one key per environment in the External Credential, rotated; access through permission set groups; injection cases in the golden set.

**4. Deployment.** Salesforce: GitHub and pull requests, then Gearset (or the sf CLI in GitHub Actions) from dev sandbox to UAT to production with a validation only deploy and a quick deploy. Anything outside Salesforce, such as the eval runner or a future orchestration service: Cloud Run via GitHub Actions, Secret Manager and Terraform.

**5. Monitoring.** A RevOps dashboard on the run log: volume, fallback rate by failure code, latency, cost, removal rate and confidence. Slack alerts when fallbacks exceed 10% in an hour or cost exceeds budget. Nebula Logger for Apex errors and Cloud Monitoring for services.

**6. Rollout.** A kill switch in Custom Metadata. Week 1: shadow mode for one pod, where briefs are generated and reviewed by RevOps but not sent. Weeks 2 to 4: pilot. Expand by region when fallbacks stay under 5% and AE ratings beat the baseline.

**7. Rollback.** Turn the kill switch off and redeploy the previous prompt or metadata version. The solution only adds records, so no data rollback is needed.

**8. Enablement.** A short Loom for ADRs on Prepare Handover; an AE guide to source links, [Rule] versus [AI], editing and regenerating; a Slack channel and office hours during the pilot.

**9. Iterate.** A weekly review of metrics and the lowest rated briefs, deciding whether each fix belongs in capture, rules, prompt or model.

@@ADDITIONAL
**1. How long did it take?**

About 6 hours: design, the build with an AI coding agent and my review, deployment and testing in the org, the video and this write up. Most of the time went into decisions, not code.

**2. Edge cases not fully covered**

- The same email logged as a Salesloft Task and as an EmailMessage appears twice.
- Long call summaries are cut at 1,000 characters, and activity on Leads or beyond the cap of 25 is dropped.
- Contradictions over time, such as an old email saying budget approved while the field says unknown, are not enforced.
- Owner changes after the brief, deleted or merged cited records, renewals that should not trigger a handover, and multi currency.
- Edit tracking works per line, not per word.

**3. Limitations, and where the model can be confidently wrong**

The checks prove a statement is traceable, not that it is true. A misread field ("budget approved" citing "Identified, not approved"), wrong attribution between two real contacts, or an inference stated as fact would pass. The name check also misses an invented name at the start of a sentence, and occasionally removes a correct sentence (in testing, one mentioning the field name "Amount"). A user notices through the source link on every statement, the [AI] label, the confidence and removed count, and the validation report. The next step would be deterministic checks of budget, timeline and decision maker claims against the actual field values.

**4. Data kept away from the model**

Contact emails, phones and addresses, which are personal data the brief does not need. Full email bodies, quoted threads and raw transcripts, which carry third party data and are the main injection surface. Other deals and pricing, which are commercially sensitive. Anything the triggering user cannot see, enforced by user mode queries.

**5. Cost and duration**

Measured in the org: about 20 seconds per brief, up to 3,100 output tokens and about 6,000 to 9,000 input tokens. At Sonnet tier prices that is roughly 5 to 7 US cents per brief, or under 50 USD a month at a few hundred handovers. It runs asynchronously, so nobody waits. To cut cost: prompt caching for the static prompt and schema, a cheaper model first with escalation on low confidence, and a tighter fact sheet. To cut latency: shorter sections, a smaller model, or moving the call to Cloud Run if streaming is needed.

**6. AI assisted development**

I used Claude Code as a pair programmer. I set the design and the engineering calls (async per opportunity for callout limits, user mode reads, a Named Credential for the key, deterministic checks around the model), and it generated the Apex and Lightning code against them. I reviewed and redirected its changes, configured the org myself, and tested every scenario by hand, checking briefs against their source records. Real deployment surfaced model API differences and a prompt injection edge case, both fixed.
